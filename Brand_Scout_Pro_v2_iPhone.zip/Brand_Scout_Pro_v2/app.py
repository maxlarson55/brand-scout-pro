import csv
import io
import re
import time
import random
import string
from datetime import datetime, timezone
from functools import lru_cache

import requests
from flask import Flask, jsonify, request, send_file, send_from_directory

app = Flask(__name__, static_folder="static")
UA = "BrandScout/2.0 contact: local-app"
RDAP = "https://rdap.verisign.com/com/v1/domain/{}.com"

ONSETS = ["b","br","bl","d","dr","f","fl","g","gr","k","kl","kr","l","m","n","p","pr","pl","r","s","sh","sk","sl","sm","sn","st","t","tr","v","w","z"]
VOWELS = ["a","e","i","o","u","ae","ai","ea","io","oa"]
CODAS = ["","","","n","r","s","m","l","t"]
ENDINGS = ["a","o","i","y","en","on","io","ia","ly","ra","ro","va","vo","na","no","la","lo","mi","mo","za","zo"]

NICHES = {
    "general": ["startup", "creator economy", "AI tools", "consumer apps", "online shopping"],
    "beauty": ["skincare", "beauty", "K-beauty", "personal care", "wellness"],
    "ai": ["artificial intelligence", "AI agents", "automation", "productivity software", "AI tools"],
    "fashion": ["fashion", "streetwear", "sustainable fashion", "accessories", "beauty trends"],
    "wellness": ["wellness", "sleep", "fitness", "healthy lifestyle", "self care"],
    "finance": ["fintech", "personal finance", "payments", "small business software", "AI tools"],
    "food": ["functional food", "coffee", "healthy snacks", "food delivery", "plant based"],
    "gaming": ["gaming", "indie games", "game development", "creator economy", "mobile games"],
}

def score_word(word):
    p, m, flex = 100, 100, 100
    if len(word) > 5: p -= (len(word)-5)*7
    if re.search(r"[^aeiou]{3,}", word): p -= 20
    if re.search(r"[aeiou]{3,}", word): p -= 15
    if re.search(r"q[^u]", word): p -= 20
    transitions = sum((word[i] in "aeiou") != (word[i+1] in "aeiou") for i in range(len(word)-1))
    if len(word) >= 4 and transitions >= 2: p += 5
    if len(word) == 6: m -= 8
    if len(word) >= 7: m -= 18
    if re.search(r"(.)\1", word): m += 3
    if len(set(word)) >= 7: m -= 8
    if word.endswith(("a","o","i","y","io","ia")): m += 5
    p, m = max(0,min(100,p)), max(0,min(100,m))
    return p, m, flex

def generate_words(count=1000, min_len=4, max_len=6, style="all", seed=None):
    rng = random.Random(seed)
    style_sets = {
        "all": (ONSETS, VOWELS, ENDINGS),
        "soft": (["l","m","n","v","s","sh","b","r","w"], ["a","e","i","o","ia","ea","ai"], ["a","ia","y","la","na","mi","va","ora","elle"]),
        "tech": (["k","kr","z","v","d","t","r","n","b","tr","sk"], ["a","e","i","o","io","ai"], ["ix","ex","on","io","ora","eo","yn","os","is"]),
        "bold": (["br","dr","gr","kr","z","v","t","r","bl","st","fl"], ["a","o","u","ai","oa"], ["ox","or","ax","zo","ra","ro","on","ar","za","vo"])
    }
    ons, vows, ends = style_sets.get(style, style_sets["all"])
    words = set()
    attempts = 0
    while len(words) < min(count, 10000) and attempts < count * 100:
        attempts += 1
        if rng.random() < .65:
            word = rng.choice(ons) + rng.choice(vows) + rng.choice(ends)
        else:
            word = rng.choice(ons) + rng.choice(vows) + rng.choice(ons) + rng.choice(vows)
            if rng.random() < .45: word += rng.choice(["n","r","s","m","l",""])
        if min_len <= len(word) <= max_len and re.search("[aeiou]", word) and not re.search(r"[aeiou]{3,}|[^aeiou]{3,}|(.)\1\1", word):
            words.add(word)
    return list(words)

def check_domain(name):
    try:
        r = requests.get(RDAP.format(name), timeout=8, headers={"Accept":"application/rdap+json","User-Agent":UA})
        if r.status_code == 404:
            return "not_found_rdap"
        if r.status_code == 200:
            return "registered"
        return "unknown"
    except requests.RequestException:
        return "check_failed"

@lru_cache(maxsize=64)
def get_trends(keyword, geo="US", timeframe="today 1-m"):
    """Google Trends via pytrends (unofficial; may fail or be rate-limited)."""
    try:
        from pytrends.request import TrendReq
        pytrends = TrendReq(hl="en-US", tz=0, timeout=(5, 15), retries=0, backoff_factor=0)
        pytrends.build_payload([keyword], cat=0, timeframe=timeframe, geo=geo, gprop="")
        df = pytrends.interest_over_time()
        if df is None or df.empty or keyword not in df:
            return {"status":"no_data", "growth":None, "latest":None, "series_points":0}
        values = [int(v) for v in df[keyword].tolist()]
        if len(values) < 4:
            return {"status":"insufficient_data", "growth":None, "latest":values[-1] if values else None, "series_points":len(values)}
        n = max(2, len(values)//4)
        old = sum(values[:n])/n
        recent = sum(values[-n:])/n
        growth = round(((recent-old)/max(old,1))*100, 1)
        return {"status":"ok", "growth":growth, "latest":values[-1], "series_points":len(values)}
    except Exception:
        return {"status":"unavailable", "growth":None, "latest":None, "series_points":0}

def trend_context(niche, geo):
    terms = NICHES.get(niche, NICHES["general"])
    results = []
    for term in terms[:4]:
        item = get_trends(term, geo, "today 1-m")
        item["keyword"] = term
        results.append(item)
        time.sleep(.25)
    usable = [x["growth"] for x in results if x["growth"] is not None]
    avg = round(sum(usable)/len(usable), 1) if usable else None
    return {"status":"ok" if usable else "unavailable", "average_growth":avg, "terms":results}

def trend_score(context):
    growth = context.get("average_growth")
    if growth is None: return None
    # Convert growth to bounded 0-100 score; this is a heuristic, not a prediction.
    return round(max(0, min(100, 50 + growth/4)), 1)

@app.get("/")
def index():
    return send_from_directory("static", "index.html")

@app.get("/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json")

@app.get("/sw.js")
def sw():
    return send_from_directory("static", "sw.js")

@app.get("/api/health")
def health():
    return jsonify({"ok":True,"version":"2.0"})

@app.post("/api/search")
def search():
    body = request.get_json(silent=True) or {}
    count = max(10, min(int(body.get("count", 100)), 500))
    min_len = max(3, min(int(body.get("min_len", 4)), 8))
    max_len = max(min_len, min(int(body.get("max_len", 6)), 10))
    style = body.get("style", "all")
    niche = body.get("niche", "general")
    geo = body.get("geo", "US")
    do_domains = bool(body.get("check_domains", True))
    do_trends = bool(body.get("check_trends", True))
    words = generate_words(max(count*5, 500), min_len, max_len, style)
    rows = []
    trend_data = trend_context(niche, geo) if do_trends else {"status":"not_requested","average_growth":None,"terms":[]}
    ts = trend_score(trend_data)
    for word in words:
        p, m, f = score_word(word)
        brand = round(p*.4 + m*.35 + f*.25, 1)
        # Do not claim a word's own search demand based on unrelated niche keywords.
        overall = round(brand*.75 + ts*.25, 1) if ts is not None else brand
        rows.append({
            "name":word, "domain":word+".com", "score":overall,
            "brand_score":brand, "pronounceability":p, "memorability":m,
            "flexibility":f, "domain_status":"not_checked",
            "trend_score":ts, "trend_context":trend_data.get("average_growth"),
            "trend_status":trend_data["status"]
        })
    rows.sort(key=lambda x:x["score"], reverse=True)
    # Domain lookups are limited to avoid flooding RDAP.
    if do_domains:
        for row in rows[:min(count, 100)]:
            row["domain_status"] = check_domain(row["name"])
            time.sleep(.12)
    results = rows[:count]
    return jsonify({
        "generated_at":datetime.now(timezone.utc).isoformat(),
        "results":results,
        "trend_context":trend_data,
        "notice":"Trend data is contextual to the selected niche, not proof that an individual invented name will trend. RDAP results are preliminary."
    })

@app.post("/api/check-domain")
def domain():
    body = request.get_json(silent=True) or {}
    name = re.sub(r"[^a-z]", "", str(body.get("name","")).lower())
    if not 2 <= len(name) <= 63:
        return jsonify({"status":"invalid"}), 400
    return jsonify({"name":name, "domain":name+".com", "status":check_domain(name)})

@app.post("/api/export")
def export():
    body = request.get_json(silent=True) or {}
    rows = body.get("rows", [])
    output = io.StringIO()
    fields = ["name","domain","score","brand_score","pronounceability","memorability","flexibility","domain_status","trend_score","trend_context","trend_status"]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    mem = io.BytesIO(("\ufeff"+output.getvalue()).encode("utf-8"))
    mem.seek(0)
    return send_file(mem, mimetype="text/csv; charset=utf-8", as_attachment=True, download_name="brand-scout-results.csv")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=False)
