BRAND SCOUT PRO v2 — iPhone-ready web app

WHAT IT DOES
- Generates short invented names with style and length controls.
- Scores pronounceability, memorability and brand flexibility.
- Optionally checks .com registration records through Verisign RDAP.
- Optionally samples Google Trends interest for related keywords in a selected niche and region.
- Saves favorites in browser localStorage.
- Exports results to CSV.
- Includes PWA manifest/service worker for adding the hosted site to the iPhone Home Screen.

IMPORTANT LIMITATIONS
- This is a starter app, not a guaranteed predictor of viral popularity.
- Google Trends access uses pytrends, an unofficial interface. It can be rate-limited, change, or fail. Trend score is contextual to a niche's seed keywords; it is NOT search demand for each invented name.
- RDAP status is preliminary; confirm exact availability and price with a registrar.
- No trademark clearance is performed. Search relevant trademark databases and seek legal advice before commercial use.
- Domain checks are capped at 100 per run to limit requests.
- Favorites are stored in the browser on that device.

RUN LOCALLY
1. Install Python 3.10+.
2. In this folder run: python -m venv .venv
3. Activate the environment, then: pip install -r requirements.txt
4. Run: python app.py
5. Open http://127.0.0.1:8080 on the same computer.

DEPLOY FOR IPHONE
Deploy this folder as a Python/Flask web service on a host supporting Python and HTTPS, with app.py, requirements.txt, Procfile, runtime.txt and static/ preserved. Then open the HTTPS URL in Safari -> Share -> Add to Home Screen.
The zip does not itself publish the app online. You must deploy it to a hosting account you control.
